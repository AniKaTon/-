 document.getElementById('w1').onclick = function(){
	
	 document.getElementById('vi').innerHTML="<video src='House.of.Cards.2013.S01E01_HDRip.avi'></video>'";
 }
 
